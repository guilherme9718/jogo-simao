#include "Animadora.h"

Animadora::Animadora() {
}

Animadora::~Animadora() {
}

#pragma once
#include "stdafx.h"
#include "Obstaculo.h"

class Galhos : public Obstaculo {
public:
    Galhos();
    ~Galhos();
private:
    
};


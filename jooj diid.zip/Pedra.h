#pragma once
#include "stdafx.h"
#include "Obstaculo.h"

class Pedra : public Obstaculo {
public:
    Pedra();
    ~Pedra();
    
private:

};



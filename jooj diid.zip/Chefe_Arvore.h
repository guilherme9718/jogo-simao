#pragma once
#include "stdafx.h"
#include "Inimigo.h"

class Chefe_Arvore : public Inimigo {
public:
    Chefe_Arvore();
    ~Chefe_Arvore();
private:

};


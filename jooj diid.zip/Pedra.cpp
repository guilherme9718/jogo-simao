#include "Pedra.h"

Pedra::Pedra() {
}

Pedra::~Pedra() {
}


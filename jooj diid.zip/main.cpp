#include "stdafx.h"
#include "Jogo.h"


int main (void) 
{
    Jogo jogo;
    jogo.executar();
    
    return 0;
}
#pragma once
#include "stdafx.h"
#include "Obstaculo.h"

class Carnivora : public Obstaculo {
public:
    Carnivora();
    ~Carnivora();
private:

};



#include "Chefe_Arvore.h"

Chefe_Arvore::Chefe_Arvore() {
}

Chefe_Arvore::~Chefe_Arvore() {
}


#pragma once
#include "stdafx.h"
#include "Jogador.h"

class Angrath : public Jogador {
public:
    Angrath();
    ~Angrath();
private:

};


#include "Carnivora.h"

Carnivora::Carnivora() {
}

Carnivora::~Carnivora() {
}


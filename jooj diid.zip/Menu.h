#pragma once
#include "stdafx.h"
#include "Ent.h"

class Menu : public Ent {
public:
    Menu();
    ~Menu();
private:

};



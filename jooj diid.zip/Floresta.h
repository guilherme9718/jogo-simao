#pragma once
#include "stdafx.h"
#include "Fase.h"

class Floresta {
public:
    Floresta();
    ~Floresta();
private:
    
};


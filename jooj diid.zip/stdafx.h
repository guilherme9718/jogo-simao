#pragma once

/* ----- BIBLIOTECAS ----- */

#include <SFML/Graphics.hpp>
using namespace sf;

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <cstdlib>
using namespace std;

#pragma once
#include "stdafx.h"

class Persistidora {
public:
    Persistidora();
    virtual ~Persistidora();
private:

};


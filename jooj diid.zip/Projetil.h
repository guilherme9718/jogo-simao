#pragma once
#include "stdafx.h"
#include "Entidade.h"

class Projetil : public Entidade {
public:
    Projetil();
    ~Projetil();
private:

};


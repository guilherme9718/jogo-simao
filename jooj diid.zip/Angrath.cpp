#include "Angrath.h"

Angrath::Angrath() {
}

Angrath::~Angrath() {
}


#include "Obstaculo.h"

Obstaculo::Obstaculo(){
}

Obstaculo::~Obstaculo() {
}


#include "Persistidora.h"

Persistidora::Persistidora() {
}

Persistidora::~Persistidora() {
}


#include "Projetil.h"

Projetil::Projetil() {
}

Projetil::~Projetil() {
}


#pragma once
#include "stdafx.h"

class Animadora {
public:
    Animadora();
    ~Animadora();
private:

};


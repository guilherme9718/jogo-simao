#pragma once
#include "stdafx.h"
#include "Inimigo.h"

class Atiradino : public Inimigo {
public:
    Atiradino();
    ~Atiradino();
private:

};


#include "Atiradino.h"

Atiradino::Atiradino() {
}

Atiradino::~Atiradino() {
}

